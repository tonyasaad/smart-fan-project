/**********************************************
 * 				KEYPAD.h
 *
 * 		 Created on: Feb 22, 2023
 *      Author: Muhammad Abdel Aziz
 ********************************************/
#ifndef HAL_KEYPAD_KEYPAD_H_
#define HAL_KEYPAD_KEYPAD_H_

#include "../../HELPERS/std_types.h"
#include "../../HELPERS/Utils.h"
#include "../../MCAL/DIO/DIO_INTERFACE.h"

#define Keypad_PORT PORTD
void keypad_init(void);
uint8 keypad_Getpressed(void);
#endif /* HAL_KEYPAD_KEYPAD_H_ */
