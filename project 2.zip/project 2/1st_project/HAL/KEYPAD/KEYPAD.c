/**********************************************
0 * 				KEYPAD.c
 *
 *  Created on: Feb 22, 2023
 *      Author: Muhammad Abdel Aziz
 ********************************************/

#include "../KEYPAD/KEYPAD.h"
#include <avr/delay.h>
const uint8 Kmatrix [4][4] = {{7,8,9,'/'},{4,5,6,'*'},{1,2,3,'-'}, {'c',0 ,'=','+'}};
void keypad_init()
{
	//-----------------ROWS---------------------
	DIO_vSetPinDirection(Keypad_PORT,4,OUTPUT);
	DIO_vSetPinDirection(Keypad_PORT,5,OUTPUT);
	DIO_vSetPinDirection(Keypad_PORT,6,OUTPUT);
	DIO_vSetPinDirection(Keypad_PORT,7,OUTPUT);
	DIO_vWritePin(Keypad_PORT,4,HIGH);
	DIO_vWritePin(Keypad_PORT,5,HIGH);
	DIO_vWritePin(Keypad_PORT,6,HIGH);
	DIO_vWritePin(Keypad_PORT,7,HIGH);

	//---------------COLUMNS-----------------------
	DIO_vSetPinDirection(Keypad_PORT,0,INPUT);
	DIO_vSetPinDirection(Keypad_PORT,1,INPUT);
	DIO_vSetPinDirection(Keypad_PORT,2,INPUT);
	DIO_vSetPinDirection(Keypad_PORT,3,INPUT);

	//--------------------POLLUP-------------------
	DIO_vWritePin(Keypad_PORT,0,HIGH);
	DIO_vWritePin(Keypad_PORT,1,HIGH);
	DIO_vWritePin(Keypad_PORT,2,HIGH);
	DIO_vWritePin(Keypad_PORT,3,HIGH);
}

uint8 keypad_Getpressed(void)
{
	uint8 u8KreturnValue = 0xFF;
	for(uint8 i = 4; i < 8; i++)
	{
		DIO_vWritePin(Keypad_PORT,i,LOW);
		for(uint8 j = 0; j< 4; j++)
		{
			uint8 n = 0;
			for(uint8 k = 0; k<10; k++ )
			{
				if (DIO_u8GetPinValue(Keypad_PORT,j) == 0)
					n++;
				else if (DIO_u8GetPinValue(Keypad_PORT,j) == 1)
					n = 0;
			}
			if(n>4)
			u8KreturnValue = Kmatrix[i-4][j];
		}
		DIO_vWritePin(Keypad_PORT,i,HIGH);
	}
	return u8KreturnValue;
}
