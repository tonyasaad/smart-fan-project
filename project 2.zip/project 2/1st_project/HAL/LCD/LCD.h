/*
 * LCD.h
 *
 *  Created on: Feb 22, 2023
 *      Author: Pola
 */

#ifndef HAL_LCD_LCD_H_
#define HAL_LCD_LCD_H_

#include "../../HELPERS/Utils.h"
#include "../../HELPERS/std_types.h"
#include "../../MCAL/DIO/DIO_INTERFACE.h"



#define LCD_CONT_PORT	PORTA
#define RS				1
#define EN				2
#define D4				3
#define D5				4
#define D6				5
#define D7				6

/************************************************************************/
//COMMANDS

#define CLEAR_COMMAND				0x0F
#define CLEAR_LCD					0x01
#define SET_FUNCTION				0x28
#define ENTRY_MODE					0x06
#define DISPLAY_ON					0x0C
#define TWO_LINE_EIGHT_BIT_MODE		0x38
#define CURSOS_OFF					0x0C
#define CURSOR_ON					0x0E
#define SET_CURSOR_LOC				0x80

/*
 _LCD_CLEAR=0x01,
	_LCD_CURSOR_OFF=0x0C,
	_LCD_CURSOR_ON=0x0F,
	_LCD_4BIT_MODE=0x28,
	_LCD_8BIT_MODE=0x38,
	_LCD_ON=0x0F,
	_LCD_CURSOR_UNDERLINE=0x0E,
	_LCD_CURSOR_SHIFT_LEFT=0x10,
	_LCD_CURSOR_SHIFT_RIGHT=0x14,
	_LCD_CURSOR_INCREMENT=0x06,
	_LCD_CGRAM_START_ADDRESS=0x40
 */

/************************************************************************/
//									FUNCTIONS_PROTOTYPES
/***********************************************************************/

void LCD_init(void);
void LCD_sendCommand(uint8 COMMAND);
void LCD_send_data(uint8 DATA);
void LCD_GOTO_ROW_COL(uint8 row,uint8 column);
void LCD_displayString(const char *Str);
void LCD_intgerToString(uint16 data);



#endif /* HAL_LCD_LCD_H_ */
