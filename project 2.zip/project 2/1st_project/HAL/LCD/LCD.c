/*
 * LCD.c
 *
 *  Created on: Feb 22, 2023
 *      Author: Pola
 */

#include "LCD.h"
#include "../../MCAL/TIMER/TIMER_INTERFACE_.h"     //I use my own delay that I made in timer folder
void LCD_init(void){

	TIMER0_SetConfig(); //we set the timer to be used as a delay in this file

	DIO_vSetPinDirection(PORTA, RS, OUTPUT);
	DIO_vSetPinDirection(PORTA, EN, OUTPUT);
	DIO_vSetPinDirection(PORTA, D4, OUTPUT);
	DIO_vSetPinDirection(PORTA, D5, OUTPUT);
	DIO_vSetPinDirection(PORTA, D6, OUTPUT);
	DIO_vSetPinDirection(PORTA, D7, OUTPUT);
	TIMER0_Delay_with_Blocking(2);
	LCD_sendCommand(0x33);
	LCD_sendCommand(0x32);
	LCD_sendCommand(SET_FUNCTION);

	LCD_sendCommand(CURSOR_ON);
	LCD_sendCommand(0x01);
	TIMER0_Delay_with_Blocking(2);
	LCD_sendCommand(ENTRY_MODE);
}

void LCD_sendCommand(uint8 COMMAND){
	//I COMPARE BETWEEN THE COMMAND AND THE BITS
	DIO_vWritePin(LCD_CONT_PORT, RS, LOW);
	DIO_vWritePin(LCD_CONT_PORT, D4, GET_BIT(COMMAND,4));

	DIO_vWritePin(LCD_CONT_PORT, D5, GET_BIT(COMMAND,5));
	DIO_vWritePin(LCD_CONT_PORT, D6, GET_BIT(COMMAND,6));
	DIO_vWritePin(LCD_CONT_PORT, D7, GET_BIT(COMMAND,7));



	DIO_vWritePin(LCD_CONT_PORT, EN, HIGH);
	TIMER0_Delay_with_Blocking(2);
	DIO_vWritePin(LCD_CONT_PORT, EN, LOW);
	TIMER0_Delay_with_Blocking(5);

	DIO_vWritePin(LCD_CONT_PORT, D4, GET_BIT(COMMAND,0));
	DIO_vWritePin(LCD_CONT_PORT, D5, GET_BIT(COMMAND,1));
	DIO_vWritePin(LCD_CONT_PORT, D6, GET_BIT(COMMAND,2));
	DIO_vWritePin(LCD_CONT_PORT, D7, GET_BIT(COMMAND,3));

	DIO_vWritePin(LCD_CONT_PORT, EN, HIGH);
	TIMER0_Delay_with_Blocking(2);
	DIO_vWritePin(LCD_CONT_PORT, EN, LOW);
}

void LCD_send_data(uint8 DATA){
	//I COMPARE BETWEEN THE COMMAND AND THE BITS
	DIO_vWritePin(LCD_CONT_PORT, RS, HIGH);
	DIO_vWritePin(LCD_CONT_PORT, D4, GET_BIT(DATA,4));
	DIO_vWritePin(LCD_CONT_PORT, D5, GET_BIT(DATA,5));
	DIO_vWritePin(LCD_CONT_PORT, D6, GET_BIT(DATA,6));
	DIO_vWritePin(LCD_CONT_PORT, D7, GET_BIT(DATA,7));



	DIO_vWritePin(LCD_CONT_PORT, EN, HIGH);
	TIMER0_Delay_with_Blocking(2);
	DIO_vWritePin(LCD_CONT_PORT, EN, LOW);
	TIMER0_Delay_with_Blocking(5);

	DIO_vWritePin(LCD_CONT_PORT, D4, GET_BIT(DATA,0));
	DIO_vWritePin(LCD_CONT_PORT, D5, GET_BIT(DATA,1));
	DIO_vWritePin(LCD_CONT_PORT, D6, GET_BIT(DATA,2));
	DIO_vWritePin(LCD_CONT_PORT, D7, GET_BIT(DATA,3));


	DIO_vWritePin(LCD_CONT_PORT, EN, HIGH);
	TIMER0_Delay_with_Blocking(2);
	DIO_vWritePin(LCD_CONT_PORT, EN, LOW);

}

void LCD_GOTO_ROW_COL(uint8 row,uint8 column){
	switch (row)
	{
	case 0:
		/*	Row 0	*/
		LCD_sendCommand(0x80+column);
		break;

	case 1:
		/* Row 1 */
		LCD_sendCommand(0xC0+column);
		break;
	}
}

void LCD_displayString(const char *Str)
{
	uint8 i = 0;
	while(Str[i] != '\0')
	{
		LCD_send_data(Str[i]);
		i++;
	}
}

void LCD_intgerToString(uint16 data)
{
   char buff[16]; /* String to hold the ascii result */
   itoa(data,buff,10); /* 10 for decimal */
   LCD_displayString(buff);
}


