/*
 * LM35.c
 *
 *  Created on: Mar 2, 2023
 *      Author: Pola
 */
#include "../../HELPERS/Utils.h"
#include "../../MCAL/ADC/ADC_INTERFACE.h"
#include "LM35.h"

uint8 getTemperature(void){
	uint16 volt ;

		/* Read ADC channel where the temperature sensor is connected */
		volt= ADC_GETVOLT();

		/* Calculate the temperature from the ADC value*/


	uint32 temp_value= (volt/10);
		return temp_value;
}
