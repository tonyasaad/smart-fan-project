/*
 * LM35.h
 *
 *  Created on: Mar 2, 2023
 *      Author: Pola
 */

#ifndef HAL_LM35_LM35_H_
#define HAL_LM35_LM35_H_


#include "../../HELPERS/std_types.h"

#define SENSOR_CHANNEL_ID         0
#define SENSOR_MAX_VOLT_VALUE     5
#define SENSOR_MAX_TEMPERATURE    100

uint8 getTemperature(void);

#endif /* HAL_LM35_LM35_H_ */
