/*
 * Dc_motor.c
 *
 *  Created on: Mar 2, 2023
 *      Author: dell
 */


 /******************************************************************************
 *
 * Module: DC Motor
 *
 * File Name: dc_motor.c
 *
 * Description: source file for the DC-Motor driver
 *
 *
 *******************************************************************************/

#include "DC_MOTOR.h"
#include "../../MCAL/DIO/DIO_INTERFACE.h"
#include "../../MCAL/PWM_TIMER1/PWM_INTERFACE.h"

/*
 * Description :
 * Initialize the DC Motor by:
 * 1. Setup the direction of the two motor pins as output by send the request to GPIO driver.
 * 2. Stop the motor at the beginning
 */

void DcMotor_Init(void)
{
	/* Setup the two motor pins as output pins */
	DIO_vSetPinDirection(DC_MOTOR_PORT1_ID,DC_MOTOR_PIN1_ID,OUTPUT);
	DIO_vSetPinDirection(DC_MOTOR_PORT2_ID,DC_MOTOR_PIN2_ID,OUTPUT);

	/* Motor is stopped at the beginning */
	DIO_vWritePin(DC_MOTOR_PORT1_ID,DC_MOTOR_PIN1_ID,LOW);
	DIO_vWritePin(DC_MOTOR_PORT2_ID,DC_MOTOR_PIN2_ID,LOW);
}

/*
 * Description :
 * 1. Rotate  or Stop the motor according to the state input variable.
 * 2. Control the motor speed 0 --> 100% from its maximum speed by sending to PWM driver.
 */
void DcMotor_Rotate(DcMotor_State state,uint8 speed,uint8 freq)
{

	if(state == DC_MOTOR_CW)
	{
		PWM_Generate_CHANNELA(speed,freq);
		//DIO_vWritePin(DC_MOTOR_PORT1_ID,PIN3_ID,LOGIC_HIGH);

		/* Rotates the Motor CW */
		DIO_vWritePin(DC_MOTOR_PORT1_ID,DC_MOTOR_PIN1_ID,LOW);
		DIO_vWritePin(DC_MOTOR_PORT2_ID,DC_MOTOR_PIN2_ID,HIGH);



	}
	else if(state == DC_MOTOR_ACW)
	{
		PWM_Generate_CHANNELA(speed,freq);
		//DIO_vWritePin(DC_MOTOR_PORT1_ID,PIN3_ID,LOGIC_HIGH);
		/* Rotates the Motor A-CW */
		DIO_vWritePin(DC_MOTOR_PORT1_ID,DC_MOTOR_PIN1_ID,HIGH);
		DIO_vWritePin(DC_MOTOR_PORT2_ID,DC_MOTOR_PIN2_ID,LOW);


	}
	else if(state == DC_MOTOR_STOP)
	{
		//DIO_vWritePin(DC_MOTOR_PORT1_ID,PIN3_ID,LOGIC_LOW);
		/* Stop the Motor */
		DIO_vWritePin(DC_MOTOR_PORT1_ID,DC_MOTOR_PIN1_ID,LOW);
		DIO_vWritePin(DC_MOTOR_PORT2_ID,DC_MOTOR_PIN2_ID,LOW);


	}
	else
	{
		/* Invalid Input State - Do Nothing */
	}
}
