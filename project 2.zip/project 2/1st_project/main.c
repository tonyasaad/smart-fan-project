/*
 * main.c
 *
 *  Created on: Feb 19, 2023
 *      Author: Pola
 */

#include "MCAL/DIO/DIO_INTERFACE.h"
#include "HELPERS/Utils.h"
#include "HELPERS/std_types.h"
#include "HAL/LCD/LCD.h"
#include "MCAL/TIMER/TIMER_INTERFACE_.h"
#include "HAL/KEYPAD/KEYPAD.h"
#include "MCAL/PWM_TIMER1/PWM_INTERFACE.h"
#include "MCAL/ADC/ADC_INTERFACE.h"
#include "HAL/DC MOTOR/DC_MOTOR.h"
#include "HAL/LM35/LM35.h"

typedef enum
	{
		FAN_OFF,FAN_ON
	}Fan_State;
void main(void)
{


	PWM_Init_();
		uint8 temp;
		uint8 sped;
		ADC_INIT();

		  /* initialize ADC driver */

		Fan_State Fan1 = FAN_OFF;

		/* Initialize Motor driver */
	DcMotor_Init();

		/* Initialize LCD driver */
	LCD_init();



		/* Display this string "Temp =   C" only once on LCD at the second row*/
	LCD_GOTO_ROW_COL(1,0);
		LCD_displayString("Temp=  c");

	    while(1)
	    {
	    	/* Get the temperature value */
	   	temp = getTemperature();

			/* Control the duty cycle of the output PWM signal (Fan Speed) based on the temperature value */
			if(temp >= 40)
			{
				Fan1 = FAN_ON;

			DcMotor_Rotate(DC_MOTOR_CW,100,30000); /* Rotates the motor with 100% from its speed */
			sped=100;
			}
			else if(temp >= 35)
			{
				Fan1 = FAN_ON;


			DcMotor_Rotate(DC_MOTOR_CW,80,20000); /* Rotates the motor with 80% from its speed */
				sped=80;

			}
			else if(temp >= 30)
			{
				Fan1 = FAN_ON;
				DcMotor_Rotate(DC_MOTOR_CW,50,10000); /* Rotates the motor with 50% from its speed */

				sped=50;
			}
			else if(temp >= 25)
			{
				Fan1 = FAN_ON;
				DcMotor_Rotate(DC_MOTOR_CW,30,5000); /* Rotates the motor with 30% from its speed */

				sped=30;
			}
			else
			{
				Fan1 = FAN_OFF;
				DcMotor_Rotate(DC_MOTOR_STOP,0,0); /* Stop the motor */

			}

			/* Display the temperature and FAN state */
			if(Fan1 == FAN_OFF)
			{

				LCD_GOTO_ROW_COL(0,4);
				LCD_displayString("FAN is OFF");
			}
			else
			{

				LCD_GOTO_ROW_COL(0,0);
				LCD_displayString("FAN is ON");
				LCD_GOTO_ROW_COL(0,11);
				LCD_displayString("Speed");
				LCD_GOTO_ROW_COL(1,11);

				LCD_intgerToString(sped);

			}

			/* Display the temperature value every time at same position */
			LCD_GOTO_ROW_COL(1,6);
			if(temp >= 100)
			{
				LCD_intgerToString(temp);
			}
			else
			{
				LCD_intgerToString(temp);
				/* In case the digital value is two or one digits print space in the next digit place */
				LCD_send_data(' ');
			}
	    }
	}




