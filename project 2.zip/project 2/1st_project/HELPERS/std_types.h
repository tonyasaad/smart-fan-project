/*
 * STD_TYPES
 * 	Created on: FEB 17, 2022
 *  	Author: ANTONIOUS ASAAD
 *      	VERSION 1
 */


#ifndef STANDARD_H_
#define STANDARD_H_

#define CPU_FREQ   (8000000UL)

typedef unsigned char uint8;
typedef signed char sint8;
typedef unsigned short uint16;
typedef signed char sint16;
typedef unsigned long uint32;
typedef signed long sint32;
typedef unsigned long long uint64;
typedef signed long long sint64;
typedef float  float32;
typedef double float64;

#endif /* STANDARD_H_ */
