/*
 * UTILS AND MACROS
 * 	Created on: FEB 17, 2022
 *  	Author: ANTONIOUS ASAAD
 *      	VERSION 1
 */

#ifndef UTILS_H_
#define UTILS_H_

//OPERATIONS
// macros for pin
#define SET_BIT(REG,BIT)		REG|=(1<<BIT)
#define CLEAR_BIT(REG,BIT)		REG&=~(1<<BIT)
#define GET_BIT(REG,INDEX)		((REG>>INDEX)&0x01) //RETURN 0X00 OR 0X01
#define TOG_BIT(REG,PIN)        REG^=(1<<PIN)


// macros for port
#define SET_PORT(REG)		REG|=(0XFF)
#define CLEAR_PORT(REG)		REG&=~(0XFF)
#define TOG_PORT(REG)        REG^=(0XFF)

typedef enum {
	FALSE,
	TRUE
}boolean;

#endif /* UTILS_H_ */
