/*
 * TIMER_REG.h
 *
 *  Created on: Feb 24, 2023
 *      Author: Pola
 */

#ifndef MCAL_TIMER_TIMER_REG_H_
#define MCAL_TIMER_TIMER_REG_H_


#include "../../HELPERS/std_types.h"



// TIMER0 ADDRESSES
	#define TCCR0			(*(volatile uint8*)(0x53))
#define FOC0				7
#define WGM00				6
#define COM01				5
#define COM00				4
#define WGM01				3
#define CS02				2
#define CS01				1
#define CS00				0
	#define TCNT0			(*(volatile uint8*)(0x52))

	#define OCR0			(*(volatile uint8*)(0x5C))



/*******************************************************************************/
// TIMER INTERRUFPT REGISTERs

	#define TIMSK			(*(volatile uint8*)(0x59))
#define OCIE0				1
#define TOIE0				0
#define TICIE1				5
#define OCIE1A				4
#define OCIE1B				3
#define TOIE1				2

	#define TIFR			(*(volatile uint8*)(0x58))
#define OCF0				1
#define TOV0				0
#define ICF1				5
#define OCF1A				4
#define OCF1B				3
#define TOV1				2


#endif /* MCAL_TIMER_TIMER_REG_H_ */
