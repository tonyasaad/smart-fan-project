/*
 * TIMER.c
 *
 *  Created on: Feb 24, 2023
 *      Author: Pola
 */

#include "TIMER_INTERFACE_.h"
#include "../../HELPERS/Utils.h"


Timer_Config TIMER_CONF = {NORMAL_MODE,DISABLE_INT, CLK_PRE64};

/******************************************************************************************
 * Description:
 * it's the functions that configure the timer
 * you choose the mode of timer which you want to use
 * it resets the TCNT0 too BEFORE ANY ACTION
 *
 * ****************************************************************************************/
void TIMER0_SetConfig(void){
switch(TIMER_CONF.Mode){
case NORMAL_MODE:
	CLEAR_BIT(TCCR0,WGM00);
	CLEAR_BIT(TCCR0,WGM01);

	if(TIMER_CONF.Enable_Interrupt == 1) SET_BIT(TIMSK,TOIE0);
			else CLEAR_BIT(TIMSK,TOIE0);
		break;

case CTC_MODE:
	CLEAR_BIT(TCCR0,WGM00);
	SET_BIT(TCCR0,WGM01);
		break;
	}
TCNT0=0X00;   // JUST TO RESET THE TIMER

}

/******************************************************************************************
 * Description:
 * it's the functions that activate the timer dalay with blocking the cpu
 * it makes the system stuck till the action is finished.
 * it takes from you the time_delay in milli_seconds.
 *
 * ****************************************************************************************/
void TIMER0_Delay_with_Blocking(uint16 Milli_Seconds){

	uint32 counter=0;  //timer overflow counter or compare match counter
	float32 Tck = ((float32)(TIMER_CONF.prescaler)*1000)/CPU_FREQ ; //TICK TIME IN MILLI SEC.
	uint32 NO_OVERFLOW =   Milli_Seconds/(Tck * 256);
	if(NO_OVERFLOW<Milli_Seconds/Tck * 256){NO_OVERFLOW++;}

		if(TIMER_CONF.Mode==NORMAL_MODE){
			uint32 Tinit=(uint32)(256-(Milli_Seconds/(Tck*NO_OVERFLOW)));
			TCNT0=Tinit;
			TIMER0_START();

			while(counter<NO_OVERFLOW){
				while(GET_BIT(TIFR,TOV0)==0);	//loop until flag rise
				TCNT0=Tinit;
				SET_BIT(TIFR,TOV0);    //clear overflow flag
				counter++;
				}
			counter=0;
			TIMER_STOP();
			}

		else if(TIMER_CONF.Mode==CTC_MODE){
			uint32 comparevalue = (uint32)(Milli_Seconds/(Tck*NO_OVERFLOW));
			OCR0=comparevalue;
			TIMER0_START();

			while(counter<NO_OVERFLOW){
				while(GET_BIT(TIFR,OCF0));
				counter++;
			}
			counter=0;
			TIMER_STOP();

		}
}

/******************************************************************************************
 * Description:
 * it's the functions that activates the timer delay without blocking the cpu
 * the system works normally till it's time for the function then it's interrupted with this function
 * it takes from you the time_delay in milli_seconds.
 * you have to enable the interrupt to use this function.
 * ****************************************************************************************/
void TIMER0_Delay_Without_Blocking(uint32 Milli_Seconds){

}


/******************************************************************************************
 * Description:
 * it's the functions that start the timer
 * it takes nothing just be activated
 * it's activated with the prescaler you choose
 * it's just used in timer0
 * ****************************************************************************************/
void TIMER0_START(void){
	switch(TIMER_CONF.prescaler){

	case CLK_NO_PRE:SET_BIT(TCCR0,CS00);
					CLEAR_BIT(TCCR0,CS01);
					CLEAR_BIT(TCCR0,CS02);
		break;
	case CLK_PRE8:	CLEAR_BIT(TCCR0,CS00);
					SET_BIT(TCCR0,CS01);
					CLEAR_BIT(TCCR0,CS02);
		break;
	case CLK_PRE64:	SET_BIT(TCCR0,CS00);
					SET_BIT(TCCR0,CS01);
					CLEAR_BIT(TCCR0,CS02);
		break;
	case CLK_PRE256:CLEAR_BIT(TCCR0,CS00);
					CLEAR_BIT(TCCR0,CS01);
					SET_BIT(TCCR0,CS02);
		break;
	case CLK_PRE1024:SET_BIT(TCCR0,CS00);
					CLEAR_BIT(TCCR0,CS01);
					SET_BIT(TCCR0,CS02);
		break;

	}
}

/******************************************************************************************
 * Description:
 * it's the functions that stop the timer
 * it takes nothing just be activated
 *
 * ****************************************************************************************/
void TIMER_STOP(void){
				CLEAR_BIT(TCCR0,CS00);
				CLEAR_BIT(TCCR0,CS01);
				CLEAR_BIT(TCCR0,CS02);
}

