/*
 * TIMER_INTERFACE.h
 *
 *  Created on: Feb 24, 2023
 *      Author: Pola
 */

#ifndef MCAL_TIMER_TIMER_INTERFACE_H_
#define MCAL_TIMER_TIMER_INTERFACE_H_

#include "TIMER_REG.h"
/********************************************************************************/
#define NORMAL_MODE			0
#define CTC_MODE			1
/**********************************************************************************/
#define COMP_MAT_INT		0
#define  OVFLOW_INT			1
/**********************************************************************************/
#define DISABLE_INT			0
#define ENABLE_INT			1
/**********************************************************************************/
#define NO_CLOCK			0
#define CLK_NO_PRE			1
#define CLK_PRE8			8
#define CLK_PRE64			64
#define CLK_PRE256			256
#define CLK_PRE1024			1024


/****************************************************************************/
//IT'S THE STRUCT TO CALL THE MODE, ENBLE iNTERRUPT AND PRESCALER.
typedef struct
{
	uint16 Mode;
	uint16 Enable_Interrupt;
	uint32 prescaler;

}Timer_Config;

/****************************************************************************/

void TIMER0_START(void);
void TIMER_STOP(void);
void TIMER0_SetConfig(void);
void TIMER0_Delay_with_Blocking(uint16 Milli_Seconds);
void TIMER0_Delay_Without_Blocking(uint32 Milli_Seconds);
#endif /* MCAL_TIMER_TIMER_INTERFACE_H_ */
