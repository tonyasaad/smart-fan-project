/*
 * SPI_INTERFACE.h
 *
 *  Created on: Mar 4, 2023
 *      Author: Pola
 */

#ifndef MCAL_COMMUNICATION_PROTOCOLS_SPI_SPI_INTERFACE_H_
#define MCAL_COMMUNICATION_PROTOCOLS_SPI_SPI_INTERFACE_H_

#include "SPI_REG.h"

#define MASTER_MODE     1
#define SLAVE_MODE		0

/********************************************/
//APIS
void SPIinit(uint8 mode);
uint8 trancieve(uint8 data);
#endif /* MCAL_COMMUNICATION_PROTOCOLS_SPI_SPI_INTERFACE_H_ */
