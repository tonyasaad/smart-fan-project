/*
 * SPI_REG.h
 *
 *  Created on: Mar 4, 2023
 *      Author: Pola
 */

#ifndef MCAL_COMMUNICATION_PROTOCOLS_SPI_SPI_REG_H_
#define MCAL_COMMUNICATION_PROTOCOLS_SPI_SPI_REG_H_
#include "../../../HELPERS/std_types.h"

	#define SPCR		(*(volatile uint8*)0x2D)
#define	SPIE			7
#define SPE				6
#define DORD 			5
#define MSTR 			4
#define CPOL 			3
#define CPHA 			2
#define SPR1 			1
#define SPR0			0

	#define SPSR		(*(volatile uint8*)0x2E)
#define SPIF			7 //INTERRUPT FLAG
#define WCOL			6 //ERROR OF WRITING DURING TRANCFERING
#define SPI2X			0 //DOUBLE SPEED

#define SPDR			(*(volatile uint8*)0x2F)

/************************************************************/
	#define SPI_DDRB		(*(volatile uint8*)0x37)
	#define SPI_PORTB		(*(volatile uint8*)0x38)
	#define SPI_PINB		(*(volatile uint8*)0x36)

#define MISO			6
#define MOSI			5
#define SS				4
#define SCK				7


#endif /* MCAL_COMMUNICATION_PROTOCOLS_SPI_SPI_REG_H_ */
