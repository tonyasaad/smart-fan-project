/*
 * SPI.c
 *
 *  Created on: Mar 4, 2023
 *      Author: Pola
 */

#include "SPI_INTERFACE.h"
#include "../../../HELPERS/Utils.h"


static uint8 Gmode;

void SPIinit(uint8 mode){
Gmode=mode;
SET_BIT(SPCR,SPE);		//SPI ENABLE
 SET_BIT(SPCR,DORD);	//least SEGNIFICIT BIT
 CLEAR_BIT(SPCR,CPOL);	//RISING ENGE
 CLEAR_BIT(SPCR,CPHA);	// WE SEND SAMPEL ON THE FIRST EDGE

 SET_BIT(SPCR,SPR0);   	//SET THE FREQ/16
 CLEAR_BIT(SPCR,SPR1); 	//SET THE FREQ/16

#if(mode==MASTER_MODE)
	 SET_BIT(SPCR,MSTR);		//master mode

	 SET_BIT(SPI_DDRB,MOSI);
	 SET_BIT(SPI_DDRB,SCK);
	 CLEAR_BIT(SPI_DDRB,SS);
	 CLEAR_BIT(SPI_DDRB,MISO);

#elif (mode==SLAVE_MODE)
	 CLEAR_BIT(SPCR,MSTR);		//slave mode

	 CLEAR_BIT(SPI_DDRB,MOSI);
	 CLEAR_BIT(SPI_DDRB,SCK);
	 CLEAR_BIT(SPI_DDRB,SS);
	 SET_BIT(SPI_DDRB,MISO);

#endif

}

uint8 trancieve(uint8 data){
	SPDR=data;
	while(!(SPDR &(1<<SPIF)));
	return SPDR;

}

