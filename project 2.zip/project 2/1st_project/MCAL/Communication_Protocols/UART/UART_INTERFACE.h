/*
 * UART_INTERFACE.h
 *
 *  Created on: Mar 3, 2023
 *      Author: Pola
 */

#ifndef MCAL_COMMUNICATION_PROTOCOLS_UART_UART_INTERFACE_H_
#define MCAL_COMMUNICATION_PROTOCOLS_UART_UART_INTERFACE_H_


#include "UART_REG.h"

#define DISABLE			0
#define ENABLE			1
/***************************************************************/
// PARITY MACROS
#define DIS_PARITY	0
#define ODD_PARITY		1
#define EVEN_PARITY		2
/*****************************************************************/
//CHARACHTER SIZES
#define SIZE_5			0
#define SIZE_6			1
#define SIZE_7 			2
#define SIZE_8 			3
#define SIZE_9 			4
/*****************************************************************/
//STOP BITS
#define ONE_BIT 		0
#define TWO_BITS 		1
/****************************************************************/
//CONFIGURATION STRUCTURE
typedef struct{
uint8 parity;
uint8 character_size;
uint8 stop_bit;
uint8 TX_INT;
uint8 RX_INT;
uint8 UDR_INT;

}UART_CONFIG;

/****************************************************************/
//UART RX interrupt request
#define UART_RX_INT __vector_13

//ISR macro
#define ISR(INT_VECT) void INT_VECT(void) __attribute__ ((signal,used)); \
void INT_VECT(void)

/**************************************************************************************************************/
//APIS
void UART_INIT(uint16 BAUDRATE);
void UART_TRANSMIT(uint8 DATA);
uint8 UART_RECIEVE(void);
/*****************************/
void UCSZ_BIT_SELECT(void);
void UART_PARITY(void);
uint8 is_normalMode(uint32 BaudRate);
void UART_Set_Receive_Buffer(uint16 *RX_Buffer);


#endif /* MCAL_COMMUNICATION_PROTOCOLS_UART_UART_INTERFACE_H_ */
