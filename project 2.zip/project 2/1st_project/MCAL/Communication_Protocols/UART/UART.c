/*
 * UART.c
 *
 *  Created on: Mar 3, 2023
 *      Author: Pola
 */

#include "UART_INTERFACE.h"
#include "../../../HELPERS/Utils.h"

static uint16 *UART_RX_INT_Buffer;
UART_CONFIG UART_CONF={DIS_PARITY,SIZE_8,ONE_BIT,ENABLE,DISABLE,DISABLE};

/************************************************************************************************************
 * Description:
 * it's the function that initiate the uart communication protocol
 * it takes nothing. we just call this function before we use the uart
 *
 * **********************************************************************************************************/

void UART_INIT(uint16 BAUDRATE){
	uint16 ubrrvalue;
//we set the baudrate value and get the value we want ot write in the UBRR
	if(is_normalMode(BAUDRATE)){
		CLEAR_BIT(UCSRA,UCSRA_U2X);
		ubrrvalue= ((CPU_FREQ)/(BAUDRATE*16UL)-1);
	}
	else{
		SET_BIT(UCSRA,UCSRA_U2X);
		ubrrvalue= ((CPU_FREQ)/(BAUDRATE*8UL)-1);
	}
//assign baud rate UBBR value to UBBR register
	UBRRH=(ubrrvalue>>8);
	UBRRL=ubrrvalue;
	if(UART_CONF.RX_INT == ENABLE){
			SET_BIT(SREG,GIE);
			SET_BIT(UCSRB,UCSRB_RXCIE);
		}
	else if(UART_CONF.RX_INT == DISABLE) CLEAR_BIT(UCSRB,UCSRB_RXCIE);

//enable or disable TX interrupt
	if(UART_CONF.TX_INT == ENABLE){
			SET_BIT(SREG,GIE);
			SET_BIT(UCSRB,UCSRB_TXCIE);
		}
	else if(UART_CONF.TX_INT == DISABLE) CLEAR_BIT(UCSRB,UCSRB_TXCIE);

//enable or disable data register empty interrupt
	if(UART_CONF.UDR_INT == ENABLE){
			SET_BIT(SREG,GIE);
			SET_BIT(UCSRB,UCSRB_UDRIE);
		}
	else if(UART_CONF.UDR_INT == DISABLE) CLEAR_BIT(UCSRB,UCSRB_UDRIE);

//WE SET THE ENABLE OF THE RECIEVER AND THE TRANSMITTER
	SET_BIT(UCSRB,UCSRB_TXEN);
	SET_BIT(UCSRB,UCSRB_RXEN);
//we put zero in the UMSEL REGESTER to set the asynchronous mode
	CLEAR_BIT(UCSRC,UCSRC_UMSEL);
// to access the UBRRH REGISTER OR THE UCSRC REGISTER each time.
	SET_BIT(UCSRC,UCSRC_URSEL);
//we choose the data size size
	UCSZ_BIT_SELECT();
//choose the parity of the uart
	UART_PARITY();
// CHOOSE THE NUMBER OF THE STOP BITS
	switch(UART_CONF.stop_bit){
		case ONE_BIT: CLEAR_BIT(UCSRC,UCSRC_USBS); break;
		case TWO_BITS: SET_BIT(UCSRC,UCSRC_USBS); break;
	}


}

/************************************************************************************************************
 * Description:
 * it's the function that transmit signals of the uart protocol
 * it takes data to transmit it to the reciever. we just call this init function before we use it
 *
 * **********************************************************************************************************/

void UART_TRANSMIT(uint8 DATA){
	while(GET_BIT(UCSRA,UCSRA_UDRE)==0);
		if(UART_CONF.character_size==SIZE_9){
			if(GET_BIT(DATA,8)==0) 	CLEAR_BIT(UCSRB,UCSRB_TXB8);
			else if(GET_BIT(DATA,8)==1)	SET_BIT(UCSRB,UCSRB_TXB8);
		}
		UDR=DATA;
}

/************************************************************************************************************
 * Description:
 * it's the function that recieve signals of the uart protocol
 * it takes nothing  to recieve and it returns the data on the  UDR REGISTER
 *  we just call this init function before we use it

 * **********************************************************************************************************/

uint8 UART_RECIEVE(void){
	while(GET_BIT(UCSRA,UCSRA_RXC)==0);
		if(UART_CONF.character_size==SIZE_9){
			return((GET_BIT(UCSRB,UCSRB_RXB8)<<8)|UDR);
		}
		return UDR;
}


/************************************************************************************************************
 * Description:
 * it's the function that select the bit size in the frame that the reciever and transmiter can use.
 * it takes the size that you want to write in
 *
 * **********************************************************************************************************/

void UCSZ_BIT_SELECT(void){
	switch(UART_CONF.character_size){
	case 5:	CLEAR_BIT(UCSRC,UCSRC_UCSZ0);
			CLEAR_BIT(UCSRC,UCSRC_UCSZ1);
			CLEAR_BIT(UCSRB,UCSRB_UCSZ2);
		break;
	case 6:	SET_BIT(UCSRC,UCSRC_UCSZ0);
			CLEAR_BIT(UCSRC,UCSRC_UCSZ1);
			CLEAR_BIT(UCSRB,UCSRB_UCSZ2);
		break;
	case 7:	CLEAR_BIT(UCSRC,UCSRC_UCSZ0);
			SET_BIT(UCSRC,UCSRC_UCSZ1);
			CLEAR_BIT(UCSRB,UCSRB_UCSZ2);
		break;
	case 8:	SET_BIT(UCSRC,UCSRC_UCSZ0);
			SET_BIT(UCSRC,UCSRC_UCSZ1);
			CLEAR_BIT(UCSRB,UCSRB_UCSZ2);
		break;
	case 9:	SET_BIT(UCSRC,UCSRC_UCSZ0);
			SET_BIT(UCSRC,UCSRC_UCSZ1);
			SET_BIT(UCSRB,UCSRB_UCSZ2);
		break;


	}
}

/************************************************************************************************************
 * Description:
 * it's the function that select the PARITY in the frame that the reciever and transmiter can use.
 * it takes the parity you write in the configuration object
 *
 * **********************************************************************************************************/

void UART_PARITY(void){
	switch(UART_CONF.parity){
	case DIS_PARITY: 	CLEAR_BIT(UCSRC, UCSRC_UPM0);
						CLEAR_BIT(UCSRC, UCSRC_UPM1);
		break;
	case ODD_PARITY:	SET_BIT(UCSRC, UCSRC_UPM0);
						SET_BIT(UCSRC, UCSRC_UPM1);
		break;
	case EVEN_PARITY:	CLEAR_BIT(UCSRC, UCSRC_UPM0);
						SET_BIT(UCSRC, UCSRC_UPM1);
		break;
	}
}


/************************************************************************************************************
 * Description:
 * it's the function that calculate the persentage of the error of the baudrate
 * it returns 1 if the error is less than 1% and it works in the noraml mode
 * it return 0 if the error is greater than 1% and it works in double mode
 * **********************************************************************************************************/
uint8 is_normalMode(uint32 BaudRate){
	float32 temp_UBRR = ((float32)F_CPU/(16*BaudRate))-1;
	if((temp_UBRR - (uint16)temp_UBRR)>=0.5) temp_UBRR++;

	float32 temp_Baud = (F_CPU/(16*((uint16)temp_UBRR+1)));
	float32 error = (temp_Baud/BaudRate) -1;

	if((error <= 0.01) && (error >= -0.01)) return 1;
	else return 0;
}

void UART_Set_Receive_Buffer(uint16 *RX_Buffer){
	UART_RX_INT_Buffer = RX_Buffer;
}


ISR(UART_RX_INT){
	if(UART_CONF.character_size == SIZE_9){
		*UART_RX_INT_Buffer = ((GET_BIT(UCSRB,UCSRB_RXB8)<<8) | UDR);
	}
	else *UART_RX_INT_Buffer = UDR;
}


