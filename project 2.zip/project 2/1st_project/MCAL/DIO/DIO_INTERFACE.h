/*
 * DIO_INTERFACE.h
 *
 *  Created on: Feb 19, 2023
 *      Author: Pola
 */

#ifndef MCAL_DIO_DIO_INTERFACE_H_
#define MCAL_DIO_DIO_INTERFACE_H_
#include "DIO_REG.h"
#include"../../HELPERS/Utils.h"
#include"../../HELPERS/std_types.h"

#define PORTA		 0
#define PORTB		 1
#define PORTC		 2
#define PORTD		 3

#define INPUT		 0
#define OUTPUT		 1

#define LOW			 0
#define HIGH		 1

#define PORT_OUTPUT 0XFF
#define PORT_INPUT 	0X00

#define PORT_HIGH	0XFF
#define PORT_LOW 	0X00




// DIO_INTERFACING_PIN_FUNCTIONS
extern void DIO_vSetPinDirection	(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber,uint8 copy_u8state);
extern void DIO_vWritePin			(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber,uint8 Copy_u8value);
void DIO_vTogglePin		(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber);
uint8 DIO_u8GetPinValue		(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber);

/**************************************************************************/
// DIO_INTERFACING_PORT_FUNCTIONS

void DIO_vSetPortDirection	(uint8 Copy_u8PORT,uint8 copy_u8state);
void DIO_vWritePort			(uint8 Copy_u8PORT,uint8 Copy_u8value);
void DIO_vTogglrPort		(uint8 Copy_u8PORT);
void DIO_vWritePortValue	(uint8 Copy_u8PORT,uint8 Copy_u8value);


#endif /* MCAL_DIO_DIO_INTERFACE_H_ */
