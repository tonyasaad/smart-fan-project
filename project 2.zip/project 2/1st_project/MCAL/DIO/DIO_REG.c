/*
 * DIO_REG.c
 *
 *  Created on: Feb 19, 2023
 *      Author: Pola
 */
#include "DIO_INTERFACE.h"

/****************************************************************************************/

// CONTROLLING PINS FUNCTIONS

/***********************************************************************************/
void DIO_vSetPinDirection(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber,uint8 copy_u8state){

if(Copy_u8PORT <= PORTD && Copy_u8PinNumber <= 7){
	if(copy_u8state == INPUT){
		switch(Copy_u8PORT){
		case PORTA: CLEAR_BIT(PORTA_BASE->DDR,Copy_u8PinNumber); break;
		case PORTB: CLEAR_BIT(PORTB_BASE->DDR,Copy_u8PinNumber); break;
		case PORTC: CLEAR_BIT(PORTC_BASE->DDR,Copy_u8PinNumber); break;
		case PORTD: CLEAR_BIT(PORTD_BASE->DDR,Copy_u8PinNumber); break;

			}
		}
	else if(copy_u8state == OUTPUT){
		switch(Copy_u8PORT){
		case PORTA: SET_BIT(PORTA_BASE->DDR,Copy_u8PinNumber); break;
		case PORTB: SET_BIT(PORTB_BASE->DDR,Copy_u8PinNumber); break;
		case PORTC: SET_BIT(PORTC_BASE->DDR,Copy_u8PinNumber); break;
		case PORTD: SET_BIT(PORTD_BASE->DDR,Copy_u8PinNumber); break;

			}
		}
	}
}

/*****************************************************************/

void DIO_vWritePin(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber,uint8 Copy_u8value){

if(Copy_u8PORT <= 3 && Copy_u8PinNumber <= 7 && ((Copy_u8value==HIGH)||(Copy_u8value==LOW))){
	if(Copy_u8value==HIGH){
	switch(Copy_u8PORT){
			case PORTA: SET_BIT(PORTA_BASE->PORT,Copy_u8PinNumber); break;
			case PORTB: SET_BIT(PORTB_BASE->PORT,Copy_u8PinNumber); break;
			case PORTC: SET_BIT(PORTC_BASE->PORT,Copy_u8PinNumber); break;
			case PORTD: SET_BIT(PORTD_BASE->PORT,Copy_u8PinNumber); break;

			}
		}
	else if(Copy_u8value==LOW){
		switch(Copy_u8PORT){
				case PORTA: CLEAR_BIT(PORTA_BASE->PORT,Copy_u8PinNumber); break;
				case PORTB: CLEAR_BIT(PORTB_BASE->PORT,Copy_u8PinNumber); break;
				case PORTC: CLEAR_BIT(PORTC_BASE->PORT,Copy_u8PinNumber); break;
				case PORTD: CLEAR_BIT(PORTD_BASE->PORT,Copy_u8PinNumber); break;

				}
			}
	}
}

/*****************************************************************/

void DIO_vTogglePin		(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber){

if(Copy_u8PORT <= 3 && Copy_u8PinNumber <= 7 ){
	switch(Copy_u8PORT){
			case PORTA: TOG_BIT(PORTA_BASE->PORT,Copy_u8PinNumber); break;
			case PORTB: TOG_BIT(PORTB_BASE->PORT,Copy_u8PinNumber); break;
			case PORTC: TOG_BIT(PORTC_BASE->PORT,Copy_u8PinNumber); break;
			case PORTD: TOG_BIT(PORTD_BASE->PORT,Copy_u8PinNumber); break;

		}
	}
}

/********************************************************************/

uint8 DIO_u8GetPinValue	(uint8 Copy_u8PORT,uint8 Copy_u8PinNumber){
char val=0;
if(Copy_u8PORT <= 3 && Copy_u8PinNumber <= 7 ){
	switch(Copy_u8PORT){
			case PORTA:val = GET_BIT(PORTA_BASE->PIN,Copy_u8PinNumber); break;
			case PORTB:val = GET_BIT(PORTB_BASE->PIN,Copy_u8PinNumber); break;
			case PORTC:val = GET_BIT(PORTC_BASE->PIN,Copy_u8PinNumber); break;
			case PORTD:val = GET_BIT(PORTD_BASE->PIN,Copy_u8PinNumber); break;

		}
	}
return val;
}

/****************************************************************************************/

// CONTROLLING PORTS FUNCTIONS

/***********************************************************************************/

void DIO_vSetPortDirection	(uint8 Copy_u8PORT,uint8 copy_u8state){
	if(Copy_u8PORT <= PORTD){
		if(copy_u8state == INPUT){
			switch(Copy_u8PORT){
			case PORTA: CLEAR_PORT(PORTA_BASE->DDR); break;
			case PORTB: CLEAR_PORT(PORTB_BASE->DDR); break;
			case PORTC: CLEAR_PORT(PORTC_BASE->DDR); break;
			case PORTD: CLEAR_PORT(PORTD_BASE->DDR); break;

				}
			}
		else if(copy_u8state == OUTPUT){
			switch(Copy_u8PORT){
			case PORTA: SET_PORT(PORTA_BASE->DDR); break;
			case PORTB: SET_PORT(PORTB_BASE->DDR); break;
			case PORTC: SET_PORT(PORTC_BASE->DDR); break;
			case PORTD: SET_PORT(PORTD_BASE->DDR); break;

				}
			}
		}
}

/********************************************************************/

void DIO_vWritePort			(uint8 Copy_u8PORT,uint8 Copy_u8value){
	if(Copy_u8PORT <= PORTD){
		if(Copy_u8value == PORT_INPUT){
			switch(Copy_u8PORT){
			case PORTA: CLEAR_PORT(PORTA_BASE->PORT); break;
			case PORTB: CLEAR_PORT(PORTB_BASE->PORT); break;
			case PORTC: CLEAR_PORT(PORTC_BASE->PORT); break;
			case PORTD: CLEAR_PORT(PORTD_BASE->PORT); break;

				}
			}
		else if(Copy_u8value == PORT_OUTPUT){
			switch(Copy_u8PORT){
			case PORTA: SET_PORT(PORTA_BASE->PORT); break;
			case PORTB: SET_PORT(PORTB_BASE->PORT); break;
			case PORTC: SET_PORT(PORTC_BASE->PORT); break;
			case PORTD: SET_PORT(PORTD_BASE->PORT); break;

				}
			}
		}

}

/********************************************************************/

void DIO_vTogglrPort		(uint8 Copy_u8PORT){
	if(Copy_u8PORT <= PORTD){
			switch(Copy_u8PORT){
			case PORTA: TOG_PORT(PORTA_BASE->PORT); break;
			case PORTB: TOG_PORT(PORTB_BASE->PORT); break;
			case PORTC: TOG_PORT(PORTC_BASE->PORT); break;
			case PORTD: TOG_PORT(PORTD_BASE->PORT); break;

				}
			}


}

/********************************************************************/
