/*
 * DIO_REG.h
 *
 *  Created on: Feb 19, 2023
 *      Author: Pola
 */

#ifndef MCAL_DIO_DIO_REG_H_
#define MCAL_DIO_DIO_REG_H_
#include "../../HELPERS/std_types.h"

// structure for DIO_REG
typedef struct
{
uint8 PIN;
uint8 DDR;
uint8 PORT;
}DIO_REGS;

//PINS ADDRESSES
#define PORTA_BASE		((volatile DIO_REGS*)0x39)
#define PORTB_BASE		((volatile DIO_REGS*)0x36)
#define PORTC_BASE		((volatile DIO_REGS*)0x33)
#define PORTD_BASE		((volatile DIO_REGS*)0x30)



#endif /* MCAL_DIO_DIO_REG_H_ */
