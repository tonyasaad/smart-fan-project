/*
 * EXT_INTERRUPT.c
 *
 *  Created on: Mar 6, 2023
 *      Author: Pola
 */


