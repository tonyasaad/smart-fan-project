/*
 * PWM_INTERFACE.h
 *
 *  Created on: Mar 2, 2023
 *      Author: Pola
 */

#ifndef MCAL_PWM_TIMER1_PWM_INTERFACE_H_
#define MCAL_PWM_TIMER1_PWM_INTERFACE_H_


#include "PWM_REG.h"

/********************************************************************************************/
//TIMER1 MODES
#define FAST_PWM			0
#define PWM_C_PHASE			1


/****************************************************************************************/
//PRESCALER MODES
#define NO_CLOCK			0
#define CLK_NO_PRE			1
#define CLK_PRE8			8
#define CLK_PRE64			64
#define CLK_PRE256			256
#define CLK_PRE1024			1024

/******************************************************************************************/
//INTERRUPT OCNTROL
#define DISABLE_INT			0
#define ENABLE_INT			1

/*******************************************************************************************/
//POLARITY OCNTROL
#define NON_INVERTED			0
#define INVERTED				1

/*******************************************************************************************/

typedef struct {
	uint8 PWM_MODE;
	uint8 PWM_POLARITY;
}PWM_CONFIG;

/***************************************************************************************/
//PWM APIS
void PWM_Init_(void);
void START_PWM(uint16 prescaler);
void STOP_PWM(void);
void PWM_Generate_CHANNELA(uint8 Copy_u8DutyCycle,uint32 Copy_u32freq);
void PWM_Generate_CHANNELB(uint8 Copy_u8DutyCycle,uint32 Copy_u32freq);


#endif /* MCAL_PWM_TIMER1_PWM_INTERFACE_H_ */
