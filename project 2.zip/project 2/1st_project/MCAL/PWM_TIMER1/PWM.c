/*
 * PWM.c
 *
 *  Created on: Mar 2, 2023
 *      Author: Pola
 */

#include "PWM_INTERFACE.h"
#include "../../HELPERS/Utils.h"

#define MAX_TOP 10000

//ACTIVATE OBJECT OF THE STRUCT
PWM_CONFIG MY_PWM = {FAST_PWM,NON_INVERTED};

/***************************************************************************************************
 * DISCRIPTION:
 * IT'S THE FUNCTION THAT INITIATE THE PWM MODULE
 * IT TAKES NOTHING
 * WE HAVE TO CALL THIS FUNCTION FIRST WHEN WE WANT TO USE THE PWM MODULE.
 *
 **************************************************************************************************/
void PWM_Init_(void){
	switch(MY_PWM.PWM_MODE){   //this switch to select the mode
	case FAST_PWM:	CLEAR_BIT(TCCR1A,WGM10);
					SET_BIT(TCCR1A,WGM11);
					SET_BIT(TCCR1B,WGM12);
					SET_BIT(TCCR1B,WGM13);
	break;
	case PWM_C_PHASE:CLEAR_BIT(TCCR1A,WGM10);
					CLEAR_BIT(TCCR1A,WGM11);
					CLEAR_BIT(TCCR1B,WGM12);
					SET_BIT(TCCR1B,WGM13);
	break;
	}

	switch(MY_PWM.PWM_POLARITY){    // this switch to select the polarity of the  pwm mode
	case NON_INVERTED:CLEAR_BIT(TCCR1A,COM1A0);
					SET_BIT(TCCR1A,COM1A1);
					CLEAR_BIT(TCCR1A,COM1B0);
					SET_BIT(TCCR1A,COM1B1);
	break;
	case INVERTED:	SET_BIT(TCCR1A,COM1A0);
					SET_BIT(TCCR1A,COM1A1);
					SET_BIT(TCCR1A,COM1B0);
					SET_BIT(TCCR1A,COM1B1);
	break;
	}
	TCNT1L=0x00;

}

/******************************************************************************************
 * DESCRIPTION:
 * IT'S THE FUNCTION THAT GENERATE THE PWM CHANNEL_A
 * IT CALCULATE THE FREQ AND THE DUTYCYCLE OF THE MOTOR
 * IT TAKES THE REQUIRED CUTYCYCLE AND THE FREQUENCY
 *
 * *****************************************************************************************/
void PWM_Generate_CHANNELA(uint8 Copy_u8DutyCycle,uint32 Copy_u32freq){
	uint16 prescaler =1;
	SET_BIT(DDRD,5);	 //we initiate the 	PWM PIN OF PORT D
	uint32 TOP=0;
	switch(MY_PWM.PWM_MODE){

		case FAST_PWM:
			if(((float)CPU_FREQ/Copy_u32freq) < MAX_TOP) prescaler = 1;
			else if(((float)CPU_FREQ/(Copy_u32freq*8)) < MAX_TOP) prescaler = 8;
			else if(((float)CPU_FREQ/(Copy_u32freq*64)) < MAX_TOP) prescaler = 64;
			else if(((float)CPU_FREQ/(Copy_u32freq*256)) < MAX_TOP) prescaler = 256;
			else if(((float)CPU_FREQ/(Copy_u32freq*1024)) < MAX_TOP) prescaler = 1024;

			TOP = (float32)(CPU_FREQ/(prescaler*Copy_u32freq));
			ICR1L=TOP;	 //WE PUT THE FREQ IN THE ICR AFTER CALCULATION

			if(MY_PWM.PWM_POLARITY==NON_INVERTED){
				if(Copy_u8DutyCycle == 0) OCR1AL = 0;
				else OCR1AL = (((float)Copy_u8DutyCycle*(TOP+1))/255) - 1;
			}
			else if(MY_PWM.PWM_POLARITY==INVERTED){
				if(Copy_u8DutyCycle == 255) OCR1AL = 0;
				else OCR1AL = TOP - (((float)Copy_u8DutyCycle*(TOP+1))/255);
			}
			START_PWM(prescaler);
	break;

		case PWM_C_PHASE:
			if(((float)CPU_FREQ/(Copy_u32freq*2)) < (MAX_TOP-1)) prescaler = 1;
			else if(((float)CPU_FREQ/(Copy_u32freq*2*8)) < (MAX_TOP-1)) prescaler = 8;
			else if(((float)CPU_FREQ/(Copy_u32freq*2*64)) < (MAX_TOP-1)) prescaler = 64;
			else if(((float)CPU_FREQ/(Copy_u32freq*2*256)) < (MAX_TOP-1)) prescaler = 256;
			else if(((float)CPU_FREQ/(Copy_u32freq*2*1024)) < (MAX_TOP-1)) prescaler = 1024;

			TOP = ((float)CPU_FREQ/(Copy_u32freq*2*prescaler));

			if(MY_PWM.PWM_POLARITY==NON_INVERTED){
				if(Copy_u8DutyCycle == 0) OCR1AL = 0;
				else OCR1AL = (((float)Copy_u8DutyCycle*TOP)/255);
			}
			else if(MY_PWM.PWM_POLARITY==INVERTED){
				if(Copy_u8DutyCycle == 255) OCR1AL = 0;
				else OCR1AL = TOP - (((float)Copy_u8DutyCycle*TOP)/255);
			}
			START_PWM(prescaler);
	break;
	}

}

/************************************************************************************************************
* DESCRIPTION:
 * IT'S THE FUNCTION THAT GENERATE THE PWM CHANNEL_B
 * IT CALCULATE THE FREQ AND THE DUTYCYCLE OF THE MOTOR
 * IT TAKES THE REQUIRED CUTYCYCLE AND THE FREQUENCY
 *
 * ************************************************************************************************************/
void PWM_Generate_CHANNELB(uint8 Copy_u8DutyCycle,uint32 Copy_u32freq){

	uint16 prescaler =1;
	SET_BIT(DDRD,4);	 //we initiate the 	PWM PIN OF PORT D
	uint32 TOP=0;
	switch(MY_PWM.PWM_MODE){

		case FAST_PWM:
			if(((float)CPU_FREQ/Copy_u32freq) < MAX_TOP) prescaler = 1;
			else if(((float)CPU_FREQ/(Copy_u32freq*8)) < MAX_TOP) prescaler = 8;
			else if(((float)CPU_FREQ/(Copy_u32freq*64)) < MAX_TOP) prescaler = 64;
			else if(((float)CPU_FREQ/(Copy_u32freq*256)) < MAX_TOP) prescaler = 256;
			else if(((float)CPU_FREQ/(Copy_u32freq*1024)) < MAX_TOP) prescaler = 1024;

			TOP = (float32)(CPU_FREQ/(prescaler*Copy_u32freq));
			ICR1L=TOP;	 //WE PUT THE FREQ IN THE ICR AFTER CALCULATION

			if(MY_PWM.PWM_POLARITY==NON_INVERTED){
				if(Copy_u8DutyCycle == 0) OCR1BL = 0;
				else OCR1BL = (((float)Copy_u8DutyCycle*(TOP+1))/255) - 1;
			}
			else if(MY_PWM.PWM_POLARITY==INVERTED){
				if(Copy_u8DutyCycle == 255) OCR1BL = 0;
				else OCR1BL = TOP - (((float)Copy_u8DutyCycle*(TOP+1))/255);
			}
			START_PWM(prescaler);
	break;

		case PWM_C_PHASE:
			if(((float)CPU_FREQ/(Copy_u32freq*2)) < (MAX_TOP-1)) prescaler = 1;
			else if(((float)CPU_FREQ/(Copy_u32freq*2*8)) < (MAX_TOP-1)) prescaler = 8;
			else if(((float)CPU_FREQ/(Copy_u32freq*2*64)) < (MAX_TOP-1)) prescaler = 64;
			else if(((float)CPU_FREQ/(Copy_u32freq*2*256)) < (MAX_TOP-1)) prescaler = 256;
			else if(((float)CPU_FREQ/(Copy_u32freq*2*1024)) < (MAX_TOP-1)) prescaler = 1024;

			TOP = ((float)CPU_FREQ/(Copy_u32freq*2*prescaler));

			if(MY_PWM.PWM_POLARITY==NON_INVERTED){
				if(Copy_u8DutyCycle == 0) OCR1BL = 0;
				else OCR1BL = (((float)Copy_u8DutyCycle*TOP)/255);
			}
			else if(MY_PWM.PWM_POLARITY==INVERTED){
				if(Copy_u8DutyCycle == 255) OCR1BL = 0;
				else OCR1BL = TOP - (((float)Copy_u8DutyCycle*TOP)/255);
			}
			START_PWM(prescaler);
	break;
	}

}

/******************************************************************************************
 * Description:
 * it's the functions that start the PWM
 * it takes nothing just be activated
 * it's activated with the prescaler you choose
 * it's just used in timer1 (PWM)
 * ****************************************************************************************/
void START_PWM(uint16 prescaler){
	switch(prescaler){

	case CLK_NO_PRE:SET_BIT(TCCR1B,CS10);
					CLEAR_BIT(TCCR1B,CS11);
					CLEAR_BIT(TCCR1B,CS12);
		break;
	case CLK_PRE8:	CLEAR_BIT(TCCR1B,CS10);
					SET_BIT(TCCR1B,CS11);
					CLEAR_BIT(TCCR1B,CS12);
		break;
	case CLK_PRE64:	SET_BIT(TCCR1B,CS10);
					SET_BIT(TCCR1B,CS11);
					CLEAR_BIT(TCCR1B,CS12);
		break;
	case CLK_PRE256:CLEAR_BIT(TCCR1B,CS10);
					CLEAR_BIT(TCCR1B,CS11);
					SET_BIT(TCCR1B,CS12);
		break;
	case CLK_PRE1024:SET_BIT(TCCR1B,CS10);
					CLEAR_BIT(TCCR1B,CS11);
					SET_BIT(TCCR1B,CS12);
		break;

	}
}

/******************************************************************************************
 * Description:
 * it's the functions that stop the PWM
 * it takes nothing just be activated
 *
 * ****************************************************************************************/
void STOP_PWM(void){
				CLEAR_BIT(TCCR1B,CS10);
				CLEAR_BIT(TCCR1B,CS11);
				CLEAR_BIT(TCCR1B,CS12);
}
