/*
 * PWM_REG.h
 *
 *  Created on: Mar 2, 2023
 *      Author: Pola
 */

#ifndef MCAL_PWM_TIMER1_PWM_REG_H_
#define MCAL_PWM_TIMER1_PWM_REG_H_

#include "../../HELPERS/std_types.h"


//TIMER1 ADDRESSES

	#define TCCR1A			(*(volatile uint8*)(0x4F))
#define COM1A1				7
#define COM1A0				6
#define COM1B1				5
#define COM1B0				4
#define FOC1A				3
#define FOC1B				2
#define WGM11				1
#define WGM10				0
	#define TCCR1B			(*(volatile uint8*)(0x4E))
#define ICNC1				7
#define ICES1				6
#define WGM13				4
#define WGM12				3
#define CS12				2
#define CS11				1
#define CS10				0
	#define TCNT1L			(*(volatile uint16*)(0x4C))
	#define OCR1AL			(*(volatile uint16*)(0x4A))
	#define OCR1BL			(*(volatile uint16*)(0x48))
	#define ICR1L			(*(volatile uint16*)(0x46))

	#define DDRD			(*(volatile uint8*)(0x31))



/*******************************************************************************/
// TIMER INTERRUFPT REGISTERs

	#define TIMSK			(*(volatile uint8*)(0x59))
#define OCIE0				1
#define TOIE0				0
#define TICIE1				5
#define OCIE1A				4
#define OCIE1B				3
#define TOIE1				2

	#define TIFR			(*(volatile uint8*)(0x58))
#define OCF0				1
#define TOV0				0
#define ICF1				5
#define OCF1A				4
#define OCF1B				3
#define TOV1				2



#endif /* MCAL_PWM_TIMER1_PWM_REG_H_ */
