/*
 * ADC_INTERFACE.h
 *
 *  Created on: Feb 26, 2023
 *      Author: Pola
 */

#ifndef MCAL_ADC_ADC_INTERFACE_H_
#define MCAL_ADC_ADC_INTERFACE_H_

#include "ADC_REG.h"


/*************************************************************************************/
//this is prescaler macros to control the speed of the ADC
#define RESERVED_clk		0
#define CLK_PRE2			2
#define CLK_PRE4			4
#define CLK_PRE8			8
#define CLK_PRE16			16
#define CLK_PRE32			32
#define CLK_PRE64			64
#define CLK_PRE128			128

/*************************************************************************************/
#define ENABLE_INTERRUPT	1
#define DISABLE_INTERRUPT	0
/*************************************************************************************/
//THIS IS THE VOLTAGE SOURE OF THE
#define SOURCE_OFF			0
#define AVCC_SOURCE_5V		1
#define RESERVED_S			2
#define INTERNAL_SC_2V		3
/*************************************************************************************/
//THIS IS THE CHANNELS OF THE ADC
#define channel_0			0
#define channel_1			1
#define channel_2			2
#define channel_3			3
#define channel_4			4
#define channel_5			5
#define channel_6			6
#define channel_7			7

/***************************************************************************************/
// THIS IS THE SOURCE OF THE AUTO TRIGGER
#define FREE_RUN_MODE			0
#define ANALOG_COMPARATOR		1
#define EXT_INTERRUPT_REQ0		2
#define TIMER0_COMPARE			3
#define TIMER0_OVERFLOW			4
#define TIMER_COMPARE_B			5
#define TIMER1_OVERFLOW			6
#define TIMER1_CAPTURE_EVENT	7

/*************************************************************************************/
//it's the struct to contain all our parameters
typedef struct{
uint8 voltage_source;
uint8 ADC_channel;
uint8 prescaler;
uint8 trigger_source_mode;
uint8 INTERRUPT_EN;

}ADC_CONFIGER;


void ADC_INIT(void);
uint16 GET_SIGNAL(void);
uint16 ADC_GETVOLT(void);
/*************************/
void TRIGGER_SOURCE(void);
void CHANNEL_SELECT(void);
void VOLTAGE_SOURCE(void);
void ADC_CLK_SLC(void);







#endif /* MCAL_ADC_ADC_INTERFACE_H_ */
