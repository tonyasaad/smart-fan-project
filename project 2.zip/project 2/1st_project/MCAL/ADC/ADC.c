/*
 * ADC.c
 *
 *  Created on: Feb 26, 2023
 *      Author: Pola
 */

#include "ADC_INTERFACE.h"
#include "../../HELPERS/Utils.h"


//********************************************************************************
//we gonna make a struct to contain all our selected parameters

ADC_CONFIGER ADC_CONF = {AVCC_SOURCE_5V,channel_0,CLK_PRE128,FREE_RUN_MODE ,DISABLE_INTERRUPT};


/***************************************************************************************
 * discribtion:
 * it's the function that WE INITIATE THE ADC WITH AND WE PREPARE ALL TEH PARAMETERS OF THE ADC BEFORE WE ENABLE IT
 * IT TAKES NOTHING WE JUST WRITE IT IN THE MAIN.
 *
 * **************************************************************************************/
void ADC_INIT(void){
		// WE HAVE TO CHOOSE THE Vref SOURCE (INTERNAL OR EXTERNAL)
VOLTAGE_SOURCE();
  	  // NOW WE HAVE TO SET IN THE ADCH REISTER AND JUST 2 BITS OF THE ADCL REGISTER
CLEAR_BIT(ADMUX,ADLAR);  //RIGHT ADJUSTER OF THE ADCH,ADCL REGISTERS
  	  //WE HAVE TO CHOOSE THE CHANNEL OF THE ADC BY MUX1-4
CHANNEL_SELECT();
  	  //WE SCHOOSE THE ADC PRESCALER 128 CLOCK
ADC_CLK_SLC();
		// WE HAVE TO SET THE AUTO TRIGGER MODE BIT
 SET_BIT(ADCSRA,ADATE);
  	  //WE HAVE TO SELECT THE AUTOTRIGGER MODE OF SFIOR REGISTER
 TRIGGER_SOURCE();
  	  // NOT WE ARE READY AND HAVE TO ENABLE THE ADC
 SET_BIT(ADCSRA,ADEN);	// WE ENABLE THE ADC OF PIN 7 OF THE ADCSRA

}


/***************************************************************************************
 * discribtion:
 * it's the function that WE start the conversion from analog to degital or vice versa
 * it return the result of the converson on ADCH AND ADCL REGISTERS
 *
 * **************************************************************************************/
uint16 GET_SIGNAL(void){
 SET_BIT(ADCSRA,ADSC);// WE START THE CONVERSION

 uint16 value=0;
	switch(ADC_CONF.INTERRUPT_EN){
	case ENABLE_INTERRUPT:  SET_BIT(ADCSRA,ADIE);
							SREG=0xFF;
							break;
	case DISABLE_INTERRUPT:	CLEAR_BIT(ADCSRA,ADIE);
							break;
	}
while(GET_BIT(ADCSRA,ADIF)==0);
	value=ADCL;    // we but the value in the adcl register
return value;
}


/******************************************************************************
 * discribtion
 * it's the function that choose the prescaler of the adc
 * as it controls the speed of the adc
 * it takes the prescaler code that I made
 *
 *
 * *****************************************************************************/
void ADC_CLK_SLC(void){
	switch(ADC_CONF.prescaler){

	case RESERVED_clk:SET_BIT(ADCSRA,ADPS0);
					CLEAR_BIT(ADCSRA,ADPS1);
					CLEAR_BIT(ADCSRA,ADPS2);
		break;
	case CLK_PRE2:	CLEAR_BIT(ADCSRA,ADPS0);
					SET_BIT(ADCSRA,ADPS1);
					CLEAR_BIT(ADCSRA,ADPS2);
		break;
	case CLK_PRE4:	SET_BIT(ADCSRA,ADPS0);
					SET_BIT(ADCSRA,ADPS1);
					CLEAR_BIT(ADCSRA,ADPS2);
		break;
	case CLK_PRE8:	CLEAR_BIT(ADCSRA,ADPS0);
					CLEAR_BIT(ADCSRA,ADPS1);
					SET_BIT(ADCSRA,ADPS2);
		break;
	case CLK_PRE16:	SET_BIT(ADCSRA,ADPS0);
					CLEAR_BIT(ADCSRA,ADPS1);
					SET_BIT(ADCSRA,ADPS2);
		break;
	case CLK_PRE32:	SET_BIT(ADCSRA,ADPS0);
					CLEAR_BIT(ADCSRA,ADPS1);
					SET_BIT(ADCSRA,ADPS2);
			break;
	case CLK_PRE64:	SET_BIT(ADCSRA,ADPS0);
					CLEAR_BIT(ADCSRA,ADPS1);
					SET_BIT(ADCSRA,ADPS2);
			break;
	case CLK_PRE128:SET_BIT(ADCSRA,ADPS0);
					CLEAR_BIT(ADCSRA,ADPS1);
					SET_BIT(ADCSRA,ADPS2);
			break;

	}
}
/***************************************************************************************
 * discribtion:
 * it's the function that we select the voltage of the adc with
 * we use it by REFS0, REFS1 TO CHOOSE EXTERNAL SOURCE OR INTERNAL
 *it takes the source code that I made
 *
 * **************************************************************************************/
void VOLTAGE_SOURCE(void){
	switch(ADC_CONF.voltage_source){
	case SOURCE_OFF:		CLEAR_BIT(ADMUX,REFS0);
							CLEAR_BIT(ADMUX,REFS1);
				break;
	case AVCC_SOURCE_5V:	SET_BIT(ADMUX,REFS0);
							CLEAR_BIT(ADMUX,REFS1);
				break;
	case RESERVED_S:		CLEAR_BIT(ADMUX,REFS0);
							SET_BIT(ADMUX,REFS1);
				break;
	case INTERNAL_SC_2V:	SET_BIT(ADMUX,REFS0);
							SET_BIT(ADMUX,REFS1);
				break;

	}
}

/***************************************************************************************
 * discribtion:
 * it's the function that we select the channel of the adc.
 * we have more than 15 channel so we gonna your just the first 7
 *
 * **************************************************************************************/

void CHANNEL_SELECT(void){

	switch(ADC_CONF.ADC_channel){
	case channel_0: CLEAR_BIT(ADMUX,MUX0);
					CLEAR_BIT(ADMUX,MUX1);
					CLEAR_BIT(ADMUX,MUX2);
					CLEAR_BIT(ADMUX,MUX3);
					CLEAR_BIT(ADMUX,MUX4);
		break;
	case channel_1: SET_BIT(ADMUX,MUX0);
					CLEAR_BIT(ADMUX,MUX1);
					CLEAR_BIT(ADMUX,MUX2);
					CLEAR_BIT(ADMUX,MUX3);
					CLEAR_BIT(ADMUX,MUX4);
		break;
	case channel_2: CLEAR_BIT(ADMUX,MUX0);
					SET_BIT(ADMUX,MUX1);
					CLEAR_BIT(ADMUX,MUX2);
					CLEAR_BIT(ADMUX,MUX3);
					CLEAR_BIT(ADMUX,MUX4);
		break;
	case channel_3: SET_BIT(ADMUX,MUX0);
					SET_BIT(ADMUX,MUX1);
					CLEAR_BIT(ADMUX,MUX2);
					CLEAR_BIT(ADMUX,MUX3);
					CLEAR_BIT(ADMUX,MUX4);
		break;
	case channel_4: CLEAR_BIT(ADMUX,MUX0);
					CLEAR_BIT(ADMUX,MUX1);
					SET_BIT(ADMUX,MUX2);
					CLEAR_BIT(ADMUX,MUX3);
					CLEAR_BIT(ADMUX,MUX4);
		break;
	case channel_5: SET_BIT(ADMUX,MUX0);
					CLEAR_BIT(ADMUX,MUX1);
					SET_BIT(ADMUX,MUX2);
					CLEAR_BIT(ADMUX,MUX3);
					CLEAR_BIT(ADMUX,MUX4);
		break;
	case channel_6: CLEAR_BIT(ADMUX,MUX0);
					SET_BIT(ADMUX,MUX1);
					SET_BIT(ADMUX,MUX2);
					CLEAR_BIT(ADMUX,MUX3);
					CLEAR_BIT(ADMUX,MUX4);
		break;
	case channel_7: SET_BIT(ADMUX,MUX0);
					SET_BIT(ADMUX,MUX1);
					SET_BIT(ADMUX,MUX2);
					CLEAR_BIT(ADMUX,MUX3);
					CLEAR_BIT(ADMUX,MUX4);
		break;

	}
}

/************************************************************************************************
 * discribtion:
 * it's the funtion that we select the auto trigger source of the adc
 * we need to trigger the auto trigger bit of the ADSCRA
 *
************************************************************************************************/
void TRIGGER_SOURCE(void){
	switch(ADC_CONF.trigger_source_mode){
	case FREE_RUN_MODE: 		CLEAR_BIT(SFIOR,ADTS0);
								CLEAR_BIT(SFIOR,ADTS1);
								CLEAR_BIT(SFIOR,ADTS2);
								break;
	case ANALOG_COMPARATOR:		SET_BIT(SFIOR,ADTS0);
								CLEAR_BIT(SFIOR,ADTS1);
								CLEAR_BIT(SFIOR,ADTS2);
			break;
	case EXT_INTERRUPT_REQ0:	CLEAR_BIT(SFIOR,ADTS0);
								SET_BIT(SFIOR,ADTS1);
								CLEAR_BIT(SFIOR,ADTS2);
			break;
	case TIMER0_COMPARE:		SET_BIT(SFIOR,ADTS0);
								SET_BIT(SFIOR,ADTS1);
								CLEAR_BIT(SFIOR,ADTS2);
			break;
	case TIMER0_OVERFLOW:		CLEAR_BIT(SFIOR,ADTS0);
								CLEAR_BIT(SFIOR,ADTS1);
								SET_BIT(SFIOR,ADTS2);
			break;
	case TIMER_COMPARE_B:		SET_BIT(SFIOR,ADTS0);
								CLEAR_BIT(SFIOR,ADTS1);
								SET_BIT(SFIOR,ADTS2);
			break;
	case TIMER1_OVERFLOW:		CLEAR_BIT(SFIOR,ADTS0);
								SET_BIT(SFIOR,ADTS1);
								SET_BIT(SFIOR,ADTS2);
			break;
	case TIMER1_CAPTURE_EVENT:	SET_BIT(SFIOR,ADTS0);
								SET_BIT(SFIOR,ADTS1);
								SET_BIT(SFIOR,ADTS2);
			break;


	}

}



uint16 ADC_GETVOLT(void){
	uint16 adc=GET_SIGNAL();
	uint16 volt=((uint32)adc*5000)/1024;
	return volt;
}

